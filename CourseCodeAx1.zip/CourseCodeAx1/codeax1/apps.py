from django.apps import AppConfig


class Codeax1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'codeax1'
