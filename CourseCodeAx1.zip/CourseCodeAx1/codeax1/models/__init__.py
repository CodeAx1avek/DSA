from .course import Course,Tag,Learning,Prerequisite
from .video import Video
from .user_course import UserCourse
from .payment import Payment