from .homepage import index,HomePageView
from .courses import coursePage,MyCourseList
from .checkout import checkOut,verifyPayment
from .auth import SignupView,LoginView,signout